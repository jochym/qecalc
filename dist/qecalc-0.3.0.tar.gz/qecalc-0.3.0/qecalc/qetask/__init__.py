# To change this template, choose Tools | Templates
# and open the template in the editor.

from qecalc.qetask.pwtask import PWTask
from qecalc.qetask.phtask import PHTask
from qecalc.qetask.q2rtask import Q2RTask
from qecalc.qetask.matdyntask import MatdynTask
from qecalc.qetask.dynmattask import DynmatTask
from qecalc.qetask.dostask import DOSTask
from qecalc.qetask.projwfctask import ProjwfcTask
from qecalc.qetask.d3task import D3Task
from qecalc.qetask.cptask import CPTask





